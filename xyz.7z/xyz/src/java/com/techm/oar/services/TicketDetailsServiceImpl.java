/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.dao.TicketDetailsDao;
import java.com.techm.oar.daoFactory.DAOFactory;
import java.sql.ResultSet;

/**
 *
 * @author mslceltp997
 */
public class TicketDetailsServiceImpl implements TicketDetailsService{

    public ResultSet ticketDetails() {
        TicketDetailsDao ticketsDetailsDAO=DAOFactory.getTicketDetailsDao();
        return ticketsDetailsDAO.ticketDetails();
    }

}
