package java.com.techm.oar.services;
import java.sql.ResultSet;
public interface TicketDetailsService 
{
        public ResultSet ticketDetails();
}
