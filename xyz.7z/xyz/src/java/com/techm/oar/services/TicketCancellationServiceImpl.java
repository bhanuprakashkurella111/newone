/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.TicketCancellation;
import java.com.techm.oar.dao.TicketCancellationDao;
import java.com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class TicketCancellationServiceImpl implements TicketCancellationService{

    public int cancelTicket(TicketCancellation cancel) {
        TicketCancellationDao ticketCancellationDAO=DAOFactory.getTicketCancellationDao();
        return ticketCancellationDAO.cancelTicket(cancel);
    }
    

}
