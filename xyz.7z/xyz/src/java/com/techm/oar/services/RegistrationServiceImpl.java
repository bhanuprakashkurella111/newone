/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.RegistrationPage;
import java.com.techm.oar.dao.RegistrationDao;
import java.com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class RegistrationServiceImpl implements RegistrationService{

    public int registerUser(RegistrationPage user) {
        RegistrationDao registrationDAO=DAOFactory.getRegistrationDao();
        return registrationDAO.registerUser(user);
    }
    
}
