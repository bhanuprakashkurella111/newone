/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.Login;
import java.com.techm.oar.dao.LoginDao;
import java.com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class LoginServiceImpl implements LoginService{

    public int validateUser(Login user){
        LoginDao loginDAO=DAOFactory.getLoginDao();
        return loginDAO.validateUser(user);
    }
}


