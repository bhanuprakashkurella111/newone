/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.Login;
import java.sql.SQLException;

/**
 *
 * @author mslceltp997
 */
public interface LoginService {
        public abstract int validateUser(Login user);
}
