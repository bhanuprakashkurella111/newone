/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.TicketCancellation;

/**
 *
 * @author mslceltp997
 */
public interface TicketCancellationService {
        public abstract int cancelTicket(TicketCancellation cancel);
}
