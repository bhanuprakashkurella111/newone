/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.RegistrationPage;

/**
 *
 * @author mslceltp997
 */
public interface RegistrationService {
        public abstract int registerUser(RegistrationPage user);
}
