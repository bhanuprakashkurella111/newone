/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.services;

import java.com.techm.oar.beans.TicketBooking;
import java.com.techm.oar.dao.TicketBookingDao;
import java.com.techm.oar.daoFactory.DAOFactory;

/**
 *
 * @author mslceltp997
 */
public class TicketBookingServiceImpl implements TicketBookingService{

    public int bookTicket(TicketBooking booking) {
        TicketBookingDao ticketBookingDAO=DAOFactory.getTicketBookingDao();
        return ticketBookingDAO.bookTicket(booking);
    }
    
}
