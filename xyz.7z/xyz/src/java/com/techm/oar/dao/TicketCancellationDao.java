/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.dao;

import java.com.techm.oar.beans.TicketCancellation;

/**
 *
 * @author mslceltp997
 */
public interface TicketCancellationDao 
{
        public abstract int cancelTicket(TicketCancellation cancel);
}
