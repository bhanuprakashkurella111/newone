
package java.com.techm.oar.dao;

import java.com.techm.oar.beans.Login;
public interface LoginDao
{
        public abstract int validateUser(Login user);     
}
