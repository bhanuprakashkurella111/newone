/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.dao;

import java.com.techm.oar.beans.TicketCancellation;
import java.com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author mslceltp997
 */
public class TicketCancellationDaoImpl implements TicketCancellationDao{

    public int cancelTicket(TicketCancellation cancel) 
    {
        int check=0;
        Connection con=null;
        Statement st=null;
        int registrationId=cancel.getRegistrationID();
        System.out.println(registrationId);
        try
        {
            con=DBUtil.getConnection();
            st=con.createStatement();
            check=st.executeUpdate("delete from ticket_details1 where registrationID="+registrationId);
            System.out.println("no.of deleted details....."+check);
        }catch(SQLException se){
            se.printStackTrace();
        }
        return check;
    }

}
