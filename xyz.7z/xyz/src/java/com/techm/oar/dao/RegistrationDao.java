
package java.com.techm.oar.dao;

import java.com.techm.oar.beans.RegistrationPage;
public interface RegistrationDao 
{
        public abstract int registerUser(RegistrationPage user);
}
