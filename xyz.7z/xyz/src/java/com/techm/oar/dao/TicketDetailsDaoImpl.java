/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.dao;

import java.com.techm.oar.utils.DBUtil;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author mslceltp997
 */
public class TicketDetailsDaoImpl implements TicketDetailsDao{

    public ResultSet ticketDetails() {
        Connection con=null;
        Statement st=null;
        ResultSet rs=null;
        try{
            con=DBUtil.getConnection();
            st=con.createStatement();
            rs=st.executeQuery("select name,registrationID,gender,agency,trip,source,destination,numberOfTickets,mobileNumber from ticket_details1");
        }catch(SQLException se){
            se.printStackTrace();
        }
        return rs;
    }
    
}
