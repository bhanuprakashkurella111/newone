package java.com.techm.oar.beans;
public class TicketCancellation {
        private int registrationID;

public int getRegistrationID() {
	return registrationID;
    }

public void setRegistrationID(int registrationID) {
	this.registrationID = registrationID;
	System.out.println(registrationID);
    }
}
