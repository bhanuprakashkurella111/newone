/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.serviceFactory;

import java.com.techm.oar.services.LoginService;
import java.com.techm.oar.services.LoginServiceImpl;
import java.com.techm.oar.services.RegistrationService;
import java.com.techm.oar.services.RegistrationServiceImpl;
import java.com.techm.oar.services.TicketBookingService;
import java.com.techm.oar.services.TicketBookingServiceImpl;
import java.com.techm.oar.services.TicketCancellationService;
import java.com.techm.oar.services.TicketCancellationServiceImpl;
import java.com.techm.oar.services.TicketDetailsService;
import java.com.techm.oar.services.TicketDetailsServiceImpl;

/**
 *
 * @author mslceltp997
 */
public class ServiceFactory {
       private ServiceFactory(){}
    public static LoginService getLoginService(){
        return new LoginServiceImpl();
    }
    public static RegistrationService getRegistrationService(){
        return new RegistrationServiceImpl();
    }
    public static TicketBookingService getTicketBookingService(){
        return new TicketBookingServiceImpl();
    }
    public static TicketCancellationService getTicketCancellationService(){
        return new TicketCancellationServiceImpl();
    }
    public static TicketDetailsService getTicketDetailsService(){
        return new TicketDetailsServiceImpl();
    }
}
