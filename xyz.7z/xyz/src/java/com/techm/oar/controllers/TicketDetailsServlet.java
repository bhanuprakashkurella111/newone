package java.com.techm.oar.controllers;
import java.com.techm.oar.serviceFactory.ServiceFactory;
import java.com.techm.oar.services.TicketDetailsService;
import java.io.*;
import java.net.*;
import java.sql.ResultSet;
import javax.servlet.*;
import javax.servlet.http.*;
public class TicketDetailsServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ResultSet rs=null;
        try
        {
            
		TicketDetailsService view = ServiceFactory.getTicketDetailsService();
               rs=view.ticketDetails();
        }
        finally
        { 
            out.close();
        }
    } 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        processRequest(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        processRequest(request, response);
    }
    public String getServletInfo() {
        return "Short description";
    }
  
}
