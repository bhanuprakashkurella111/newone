package java.com.techm.oar.controllers;
import java.com.techm.oar.beans.TicketCancellation;
import java.com.techm.oar.serviceFactory.ServiceFactory;
import java.com.techm.oar.services.TicketCancellationService;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class TicketCancellationServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int check=0;
        try
        {
            int regId=Integer.parseInt(request.getParameter("registrationID"));
            TicketCancellation cancel=new TicketCancellation();
            cancel.setRegistrationID(regId);
            TicketCancellationService ticCan=ServiceFactory.getTicketCancellationService();
            check=ticCan.cancelTicket(cancel);
            if(check==1){
                request.getRequestDispatcher("cancel.jsp").forward(request, response);
                
            }
            if(check==0){
                request.getRequestDispatcher("ticketcancellation.jsp").forward(request, response);
            }
        } finally { 
            out.close();
        }
    } 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        processRequest(request, response);
    } 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    public String getServletInfo() {
        return "Short description";
    }
}
