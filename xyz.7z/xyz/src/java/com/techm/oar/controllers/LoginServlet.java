package java.com.techm.oar.controllers;
import java.com.techm.oar.beans.Login;
import java.com.techm.oar.serviceFactory.ServiceFactory;
import java.com.techm.oar.services.LoginService;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.RequestDispatcher;
public class LoginServlet extends HttpServlet 
{
private static final long serialVersionUID = 1L;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        int check=0;
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        RequestDispatcher rd=null;
        
        try 
        {
            String userName=request.getParameter("username");
            String pwd=request.getParameter("password");
            Login login=new Login();
            login.setUserName(userName);
            login.setPassword(pwd);
            LoginService loginservice=ServiceFactory.getLoginService();
            check=loginservice.validateUser(login);
            if(check==1)
            {
            request.getRequestDispatcher("FlightDetails.jsp");
            rd.forward(request, response);
            }
            if(check==0)
            {
            request.getRequestDispatcher("loginPage.jsp");
            rd.forward(request, response);
            }
         } finally 
        { 
            out.close();
        }
        
    } 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {
        processRequest(request, response);
    } 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException 
    {
        processRequest(request, response);
    }
    public String getServletInfo()
    {
        return "Short description";
    }
}
