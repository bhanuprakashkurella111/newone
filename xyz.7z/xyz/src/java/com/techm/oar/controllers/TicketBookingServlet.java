package java.com.techm.oar.controllers;
import java.com.techm.oar.beans.TicketBooking;
import java.com.techm.oar.serviceFactory.ServiceFactory;
import java.com.techm.oar.services.TicketBookingService;
import java.io.*;
import java.net.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class TicketBookingServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try 
        {
            String name = request.getParameter("name");
            System.out.println(name);
            String gender = request.getParameter("gender");
            String agency = request.getParameter("agency");
            String trip = request.getParameter("trip");
            String source = request.getParameter("source");
            String destination = request.getParameter("destination");
            int noOfTickets = Integer.parseInt(request.getParameter("numberOfTickets"));
            long mobileNo = Long.parseLong(request.getParameter("mobileNumber"));
            int regId = Integer.parseInt(request.getParameter("registrationID"));
            TicketBooking booking = new TicketBooking();
            booking.setName(name);
            booking.setGender(gender);
            booking.setAgency(agency);
            booking.setTrip(trip);
            booking.setSource(source);
            booking.setDestination(destination);
            booking.setMobileNumber(mobileNo);
            booking.setNumberOfTickets(noOfTickets);
            booking.setRegistrationID(regId);
            TicketBookingService ticSer = ServiceFactory.getTicketBookingService();
            int count = ticSer.bookTicket(booking);
            if (count == 1) {
                request.getRequestDispatcher("viewdetails.jsp").forward(request, response);
            }
        } 
        finally 
        {
            out.close();
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }
    public String getServletInfo() {
        return "Short description";
    }
  
}
