/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package java.com.techm.oar.daoFactory;

import java.com.techm.oar.dao.LoginDao;
import java.com.techm.oar.dao.LoginDaoImpl;
import java.com.techm.oar.dao.RegistrationDao;
import java.com.techm.oar.dao.RegistrationDaoImpl;
import java.com.techm.oar.dao.TicketBookingDao;
import java.com.techm.oar.dao.TicketBookingDaoImpl;
import java.com.techm.oar.dao.TicketCancellationDao;
import java.com.techm.oar.dao.TicketCancellationDaoImpl;
import java.com.techm.oar.dao.TicketDetailsDao;
import java.com.techm.oar.dao.TicketDetailsDaoImpl;

/**
 *
 * @author mslceltp997
 */
public class DAOFactory {
    private DAOFactory(){}
    public static LoginDao getLoginDao(){
        return new LoginDaoImpl();
    }
    public static RegistrationDao getRegistrationDao(){
        return new RegistrationDaoImpl();
    }
    public static TicketBookingDao getTicketBookingDao(){
        return new TicketBookingDaoImpl();
    }
    public static TicketCancellationDao getTicketCancellationDao(){
        return new TicketCancellationDaoImpl();
    }
    public static TicketDetailsDao getTicketDetailsDao(){
        return new TicketDetailsDaoImpl();
    }
}
